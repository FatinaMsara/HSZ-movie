<html>
    <head>
        <!-- Bootsrap Files -->
		<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css"></link>
		<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
		<!-- CSS Files -->
		<link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <div class="row" style="margin:25px;">
            <div class="col-md-4">
                <center><h5><u>Add Shows</u></h5></center>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="show_time">Show Time:</label>
                        <input type="text" class="form-control" name="show_time" placeholder="Show Time">
                    </div>
                    <input type="submit" class="btn btn-danger" value="Add Show" name="add_show">
                </form>
            </div>
        </div>
    </body>
</html>